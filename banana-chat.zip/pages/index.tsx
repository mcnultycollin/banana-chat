import { useState } from 'react';
import { basePrompt, getFakeChatMessages } from '../utils/chatGen';

export default function Home() {
  const [context, setContext] = useState('');
  const [tone, setTone] = useState('funny');
  const [audience, setAudience] = useState('TikTok viewers');
  const [messages, setMessages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const prompt = basePrompt(context, tone, audience);
    const result = await getFakeChatMessages(prompt);
    setMessages(result);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">🍌 Banana Chat Generator</h1>
      <textarea
        className="w-full p-2 border rounded mb-4"
        rows={4}
        placeholder="What’s happening in your video?"
        value={context}
        onChange={(e) => setContext(e.target.value)}
      />
      <div className="flex gap-4 mb-4">
        <select className="p-2 border rounded" value={tone} onChange={(e) => setTone(e.target.value)}>
          <option value="funny">Funny</option>
          <option value="chaotic">Chaotic</option>
          <option value="flirty">Flirty</option>
          <option value="wholesome">Wholesome</option>
        </select>
        <select className="p-2 border rounded" value={audience} onChange={(e) => setAudience(e.target.value)}>
          <option value="TikTok viewers">TikTok viewers</option>
          <option value="Twitch chat">Twitch chat</option>
          <option value="YouTube comments">YouTube comments</option>
        </select>
      </div>
      <button
        onClick={handleGenerate}
        className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-2 px-4 rounded"
      >
        {loading ? 'Generating...' : 'Generate Chat'}
      </button>
      <div className="mt-6 bg-gray-900 text-green-400 p-4 rounded h-80 overflow-y-scroll font-mono text-sm">
        {messages.map((msg, idx) => (
          <div key={idx} className="mb-1">{msg}</div>
        ))}
      </div>
    </div>
  );
}
