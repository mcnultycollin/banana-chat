export function basePrompt(context: string, tone = "funny", audience = "TikTok viewers") {
  return `
You are generating fake live stream chat messages for a creator video. 
Context: ${context}
Tone: ${tone}
Audience: ${audience}

Generate 20 fake live chat messages that feel like they are reacting in real time to the video. 
Include:
- Chaotic and fast-paced energy
- Usernames (quirky, Gen Z, Twitch-style)
- Emojis, slang, reactions
- Inside jokes or phrases common to ${audience} culture
Each message should be short, unique, and styled like a real chat bubble.`;
}

export async function getFakeChatMessages(prompt: string): Promise<string[]> {
  const response = await fetch("/api/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ prompt }),
  });

  const data = await response.json();
  return data.messages;
}
